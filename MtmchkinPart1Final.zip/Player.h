
#ifndef EX2_Player_H
#define EX2_Player_H

#include <iostream>
#include <stdbool.h>
#include <cstring>
using std::string;
#include "utilities.h"

class Player
{

    std::string m_name;
    int m_level;
    int m_force;
    int m_maxHP;
    int m_HP;
    int m_coins;


    public:
    static const int initial_Coins_Count = 0;
    static const int initial_Level = 1;
    static const int defualt_MaxHP = 100;
    static const int default_Force = 5;


    /**
     * @brief Construct a new player object
     * 
     * @param name string - player's name
     * @param maxHP possitive int - player's max HP
     * @param force possitive int - player's force 
     */
    Player(std::string name, int maxHP = defualt_MaxHP, int force = default_Force);


    /**
     * @brief Construct a new Player object
     * 
     */
    Player() = default;

    /**
     * @brief Construct a new Player object
     * 
     * @param player2 a pleyer to copy his stats
     */
    Player(const Player &player2);

    /**
     * @brief Destroy the Player object
     * 
     */
    ~Player() = default;

    /**
     * @brief implemation operator
     * 
     * @param Player - player to "copy" stats from
     * @return Player& 
     */
    Player& operator=(const Player& Player);

    /**
     * @brief prints the player's info by the template:
     * Player Details:
     * Name: Gandalf
     * Level: 1
     * Force: 5
     * HP: 300
     * Coins: 0
     */
    void printInfo();

    /**
     * @brief level up in 1 the player's level.
     * won't level up a 10 level player. 
     */
    void levelUp();

    /**
     * @brief returns the player's level
     * 
     */
    int getLevel() const;

    /**
     * @brief increase the player's force with 'buffUp'
     * if buffUp<=0 , do nothing
     * 
     * @param buffUp int to add the palyer's force
     */
    void buff(int buffUp);

    /**
     * @brief adds HP to the player
     * 
     * @param addHP int- to increase the player's HP with
     */
    void heal(int addHP);

    /**
     * @brief decrease the player's HP with 'damage'
     * 
     * @param damage damage to decrease
     */
    void damage(int damage);

    /**
     * @brief check if the player's HP is 0
     * 
     * @return true if the player's HP is 0
     * @return false if the player's HP is not 0
     */
    bool isKnockedOut() const;

    /**
     * @brief add coins to the player
     * 
     * @param coins how many coins to add
     */
    void addCoins(int coins);

    /**
     * @brief player is paying fo something.
     * if there are no enough coins - won't decrease money from the player
     * 
     * @param price the paying price
     * @return true if the paying was done successfully
     * @return false if there are no enough coins
     */
    bool pay(int price);

    /**
     * @brief Get the attack strength of the player
     * 
     * @return int - the attack strength
     */
    int getAttackStrength();


};

#endif