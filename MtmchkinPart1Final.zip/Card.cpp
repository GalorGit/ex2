

#include "Card.h"
#include <iostream>

 
//----------------------- Function decleration area -------------------------
//---------------------------------------------------------------------------
//----------------------- Implementation area -------------------------------
 
 
//---------------------------------------------------------------------------
 
 /*
     * C'tor of Card class
     *
     * @param type - The type of the card.
     * @param stats - The numeral stats of the card.
     * @return
     *      A new instance of Card.
    */
Card::Card(CardType type, const CardStats& stats)
{
    this -> m_effect = type;
    this -> m_stats = stats;
}
 
/*
 * Handling the player's applyEncounter with the card:
 *
 * @param player - The player.
 * @return
 *      void
 */
void Card::applyEncounter(Player& player) const
{
    if((this->m_effect) == CardType::Battle)
    {
        if((player.getAttackStrength()) >= (this->m_stats.force))
        {
            player.levelUp();
            player.addCoins(this->m_stats.loot);
            printBattleResult(true);
        }
        else
        {
            player.damage(this->m_stats.hpLossOnDefeat);
            printBattleResult(false);
        }
        return;
    }
    else if(((this->m_effect) == CardType::Heal)||((this->m_effect) == CardType::Buff))
    {
        if(player.pay(this->m_stats.cost))
        {
            if((this->m_effect) == CardType::Heal)
            {
                player.heal(this->m_stats.heal);
            }
            else
            {
                player.buff(this->m_stats.buff);
            }
        }
        return;
    }
    player.addCoins(this->m_stats.loot);
    return;
}
 
 
 
void Card::printInfo() const
{
    if((this->m_effect) == (CardType::Battle))
    {
        printBattleCardInfo(this->m_stats);
    }
    else if((this->m_effect) == (CardType::Buff))
    {
        printBuffCardInfo(this->m_stats);
    }
    else if((this->m_effect) == (CardType::Heal))
    {
        printHealCardInfo(this->m_stats);
    }
    else
    {
        printTreasureCardInfo(this->m_stats);
    }
    return;
}
 
 
 

