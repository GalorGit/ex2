#include "Player.h"

Player::Player(std::string name, int maxHP, int force)
{
    m_name = name;
    m_level = initial_Level;
    m_coins = initial_Coins_Count;
    m_force = force;
    if (force <= 0)
    {
        m_force = default_Force;
    }
    m_maxHP = maxHP;
    if (maxHP <= 0)
    {
        m_maxHP = defualt_MaxHP;
    }
    m_HP = m_maxHP;
}

Player::Player(const Player& player2)
{
    m_name = player2.m_name;
    m_level = player2.m_level;
    m_coins = player2.m_coins;
    m_force = player2.m_force;
    m_maxHP = player2.m_maxHP;
    m_HP = player2.m_HP;
}

Player& Player::operator=(const Player& player)
{
    if(this == &player){
        return *this;
    }
    m_name = player.m_name;
    m_level = player.m_level;
    m_coins = player.m_coins;
    m_force = player.m_force;
    m_maxHP = player.m_maxHP;
    m_HP = player.m_HP;
    return *this;

}


void Player::printInfo()
{
    const char *playerName = m_name.c_str();
    printPlayerInfo(playerName,m_level,m_force,m_HP,m_coins);
}

void Player::levelUp()
{
    if (m_level < 10)
    {
        m_level++;
    }
}

int Player::getLevel() const
{
    return m_level;
}

void Player::buff(int buffUp)
{
    if (buffUp > 0)
    {
        m_force += buffUp;
    }
}

void Player::heal(int addHP)
{
    if (addHP > 0)
    {
        m_HP += addHP;
        if (m_HP > m_maxHP)
        {
            m_HP = m_maxHP;
        }
    }
}

void Player::damage(int damage)
{
    if (damage > 0)
    {
        m_HP -= damage;
        if (m_HP < 0)
        {
            m_HP = 0;
        }
    }
}

bool Player::isKnockedOut() const
{
    return (m_HP == 0);
}

void Player::addCoins(int coins)
{
    if (coins > 0)
    {
        m_coins += coins;
    }
}

bool Player::pay(int price)
{
    if (m_coins < price)
    {
        return false;
    }
    if (price <= 0){
        return true;
    }
    m_coins -= price;
    return true;
}

int Player::getAttackStrength()
{
    return (m_force + m_level);
}
