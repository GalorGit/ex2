
#include "Mtmchkin.h"

#define END_OF_LINE '\0'

/*
 * C'tor of the game:
 *
 * @param playerName - The name of the player.
 * @param cardsArray - A ptr to the cards deck.
 * @param numOfCards - Num of cards in the deck.
 * @result
 *      An instance of Mtmchkin
 */
Mtmchkin::Mtmchkin(const char *playerName, const Card *cardsArray, int numOfCards)
{
    this->m_round = -1;
    this->m_numberOfCards = numOfCards;
    this->m_gameStatus = GameStatus::MidGame;
    //-----------------
    std::string name(playerName);
    this->m_player = Player(name);
    //-----------------
    
    this->m_cardDeck = new Card[numOfCards];
    for (int i = 0; i < numOfCards; i++)
    {
        this->m_cardDeck[i] = *(cardsArray + i);
    }
}

Mtmchkin::~Mtmchkin()
{
    delete[] this->m_cardDeck;
}


/*
 * Play the next Card - according to the instruction in the exercise document
 *
 * @return
 *      void
 */
void Mtmchkin::playNextCard()
{
    m_round += 1;
    if (m_round > m_numberOfCards - 1)
    {
        m_round = 0;
    }
    Card currentCard = m_cardDeck[m_round];
    currentCard.printInfo();
    currentCard.applyEncounter(m_player);
    if (m_player.getLevel() == 10)
    {
        m_gameStatus = GameStatus::Win;
    }
    if (m_player.isKnockedOut())
    {
        m_gameStatus = GameStatus::Loss;
    }
    m_player.printInfo();
}

/**
 * @brief get the game status
 *
 * @return GameStatus status
 */
GameStatus Mtmchkin::getGameStatus() const
{
    return m_gameStatus;
}

/*
 *  Check if the game ended:
 *
 *  @return
 *          True if the game ended
 *          False otherwise
 */
bool Mtmchkin::isOver() const
{
    if (m_gameStatus != GameStatus::MidGame)
    {
        return true;
    }
    return false;
}
